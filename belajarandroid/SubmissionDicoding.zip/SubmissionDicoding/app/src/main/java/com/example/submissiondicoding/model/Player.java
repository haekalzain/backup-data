package com.example.submissiondicoding.model;

public class Player {

     int foto ;
     String Nama;
     String Negara;
     String Tanggallahir;
     String detail;

    public int getFoto() {
        return foto;
    }

    public void setFoto(int foto) {
        this.foto = foto;
    }

    public String getNama() {
        return Nama;
    }

    public void setNama(String nama) {
        Nama = nama;
    }

    public String getNegara() {
        return Negara;
    }

    public void setNegara(String negara) {
        Negara = negara;
    }

    public String getTanggallahir() {
        return Tanggallahir;
    }

    public void setTanggallahir(String tanggallahir) {
        Tanggallahir = tanggallahir;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }
}
